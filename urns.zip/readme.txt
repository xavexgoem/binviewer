Objects by team t2x.

its suitable and ready for Thief 2 new dark.

INSTALLATION

Place bin files in the /obj folder of your Thief installation.


OBJECT ZIP PACKED BY CARDIA